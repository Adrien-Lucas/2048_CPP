contenu = [
    ('stylo', 'bleu', False),
    ('gomme', 'rouge', True),
    ('feutre', 'vert', False)
]

def description_trousse(contenu):
    return 'Pas encore fait ...'

print(description_trousse(contenu))
        
