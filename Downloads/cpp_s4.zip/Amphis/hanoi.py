#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""Résolution du problème des tours de Hanoï."""

import hanoi_logic
from hanoi_logic import init, move

#######
# RESOLUTION RECURSIVE


def rec_solve(n, src, aux, dst):
    if n == 0:
        return
    rec_solve(n-1, src, dst, aux)
    move(src, dst)
    rec_solve(n-1, aux, src, dst)


#######
# BLOC PRINCIPAL

n=init()
rec_solve(n, 0, 1, 2)

print("Nombre de 'move'", hanoi_logic.num)
