#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""Résolution du problème des tours de Hanoï.
Version boguée !
"""

import hanoi_logic
from hanoi_logic import init, move


#######
# RESOLUTION RECURSIVE


def rec_solve(n):
    if n == 1:
        move(0, 2)
        return
    move(0, 1)
    rec_solve(n-1)
    move(1, 2)


#######
# BLOC PRINCIPAL

n=init()
rec_solve(n)
