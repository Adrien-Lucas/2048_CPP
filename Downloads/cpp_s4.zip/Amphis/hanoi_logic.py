#! /usr/bin/env python3
# -*- coding: utf-8 -*-
"""Animation dans la console des tours de Hanoï.
"""


NUMRING = 0
RING = range(1, 0)
SEP = "   "

tower = [[], [], []]

def ask_int():
    print("Pour commencer,", end=" ")
    while True:
        n = input("entrez un entier positif:")
        try:
            n = int(n)
            if n >= 0:
                return n
            print("Erreur:", n, "est négatif !")
        except:
            print("Erreur:", repr(n), "n'a pas l'air entier...")
        print("Recommencez,", end=" ")


def init():
    global NUMRING, RING, tower
    NUMRING = ask_int()
    RING = range(1, NUMRING+1)
    tower = [[i for i in reversed(RING)], [], []]
    print("Étant donné les 3 piles d'anneaux:")
    display()
    print("Résolution du casse-tête:")
    print(" Déplacer un à un les", NUMRING, "anneaux de 0 vers 2, ")
    print(" sans jamais empiler un anneau sur un anneau plus petit.")
    return NUMRING


#######
# AFFICHAGE DES TOURS


def pos(i, n):
    if i >= n:
        return ' '
    else:
        return '='


def display_line(n, middle):
    for i in reversed(range(1, NUMRING)):
        print(end=pos(i, n))
    print(end=middle)
    for i in range(1, NUMRING):
        print(end=pos(i, n))


def display():
    for a in range(len(tower)):
        display_line(0, repr(a))
        print(end=SEP)
    print()
    print()
    for k in reversed(range(NUMRING)):
        for t in tower:
            if k >= len(t):
                display_line(0, ':')
            else:
                display_line(t[k], '=')
            print(end=SEP)
        print()
    print()


#######
# DEPLACEMENT DES TOURS


query = "Solution ?"
num = 0

def interact():
    global query
    input(query)
    query = "Suite ?"


def move(src, dst):
    global num
    num += 1
    interact()
    print("move({0}, {1})".format(src, dst))
    top = tower[src].pop()
    assert (tower[dst] == [] or top < tower[dst][-1])
    tower[dst].append(top)
    display()
    print()
