Supports des cours d'amphi du CPP S4
====================================

Ce répertoire contient les programmes Python mentionnés en
cours. N'hésitez pas à regarder/modifier ces programmes et à les
exécuter. Le répertoire contient aussi une copie des diapositives
(déjà distribuée en cours).

* `<hanoi_bug.py>`__ et `<hanoi.py>`__ correspondent respectivement à la mauvaise et à la bonne solution au problème des tours de Hanoï. Ces deux fichiers nécessitent `<hanoi_logic.py>`__ pour faire l'animation...

* `<quine.py>`__ donne l'exemple d'une instruction Python qui s'écrit elle-même (sur le principe du "répète 2 fois répète 2 fois").

* `<thmRice.py>`__ est une tentative de construire un vérificateur contredisant le théorème de Rice. Est-ce que vous voyez pourquoi ce vérificateur est incorrect ?
