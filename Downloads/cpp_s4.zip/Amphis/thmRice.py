#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Il n'existe pas de programme python "decide" comme celui proposé ci-dessous
# qui:
#   1) étant donné une chaîne "prog" représentant un programme Python
#      utilisant une variable "arg"
#   2) une valeur "val" pour la variable "arg"
# termine en répondant "True" si l'exécution de "prog"
#    dans le contexte où "arg==val" termine sans erreur,
# ou termine en répondant "False" sinon.
#
# cas particulier du thm de Rice:
#   cf. http://fr.wikipedia.org/wiki/Théorème_de_Rice

# Une tentative d'implémentation du "decide" spécifié ci-dessus
# qui n'est pas vraiment juste...
# (Voyez-vous pourquoi ?)


def decide(prog, val):
    global arg
    try:
        arg = val
        print("** decide:", repr(prog), " with arg ==", val)
        exec(prog)
        return True
    except AssertionError:
        return False
    except Exception as e:
        print("==> catch exception: ", repr(e))
        return False


def test_decide(prog, val):
    if decide(prog, val):
        print("result: ", repr(prog), " with arg ==", val, " is True")
    else:
        print("result: ", repr(prog), " with arg ==", val, " is False")


test_decide("assert arg == 5", 5)
test_decide("assert arg == 5", 4)
test_decide("True", 5)
test_decide("assert not arg == arg", 4)

print("** tapez une touche pour continuer: ", end="")
input()

test_decide("assert not decide(arg, arg)",
            "assert not decide(arg, arg)")
