# Instruction qui s'écrit elle-même
# (sur le principe du "répète 2 fois répète 2 fois")

print('print({0}.format(repr({0})))'.format(repr('print({0}.format(repr({0})))')))
