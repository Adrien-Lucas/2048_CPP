Projet 2048
======================================================

Ce répertoire contient le sujet et les sources fournies (voir ci-dessous). Vos sources Python seront **à rendre avant 17h le 15/04** sur `<https://teide.ensimag.fr/>`__.
Pensez aussi à jeter un oeil sur le `forum du projet <http://chamilo.grenoble-inp.fr/main/forum/viewforum.php?cidReq=CPP2A2CMINFO3&id_session=0&gidReq=0&gradebook=0&origin=&gidReq=0&forum=1940>`__.

Actualités
----------

  * **15/01:** Le sujet est `ici <projet-2048.pdf>`__. Les sources Python fournies par les enseignants sont données sous la forme de l'archive zip `<2048-game.zip>`__. Il faut donc télécharger cette archive et la décompresser sur votre compte avant de commencer à travailler sur les fichiers.


Enseignants du projet
---------------------


  * Groupe A : `Vivien Quéma <vivien.quema@grenoble-inp.fr>`__ et `Souha Rayana <souha.ben-rayana@inria.fr>`__

  * Groupe B : `Sylvain Boulmé <sylvain.boulme@univ-grenoble-alpes.fr>`__ et `Sameh Bouzidi <sameh.bouzidi@gmail.com>`__

  * Groupe C : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__ et `Jean Basset <jbasset001@ensc.fr>`__
    
  * Groupe D : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__ et `Sameh Bouzidi <sameh.bouzidi@gmail.com>`__

