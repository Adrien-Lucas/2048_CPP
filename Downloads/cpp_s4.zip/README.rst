Archive 2018-2019 des cours du CPP Info Semestre 4
==================================================

Vous trouverez ici les énoncés de TD, les supports des cours d'`<Amphis>`__, 
et l'énoncé du `<Projet>`__ à faire en binôme.

Actualités:
-----------

* En complément du 1er cours d'amphi, lire la section "récursivité" (pages 130 à 138) du livre "informatique pour tous en classe prépa"  de Wack et al.


Enseignants
-----------

* Amphis : `Sylvain Boulmé <sylvain.boulme@univ-grenoble-alpes.fr>`__ 

   * TDs:

     * Groupe A : `Karim Assad <karim.assaad@univ-grenoble-alpes.fr>`__

     * Groupe B : `Sylvain Boulmé <sylvain.boulme@univ-grenoble-alpes.fr>`__ 

     * Groupe C : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__

     * Groupe D : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__

   * Projet:

     * Groupe A : `Vivien Quéma <vivien.quema@grenoble-inp.fr>`__ et `Souha Rayana <souha.ben-rayana@inria.fr>`__

     * Groupe B : `Sylvain Boulmé <sylvain.boulme@univ-grenoble-alpes.fr>`__ et `Sameh Bouzidi <sameh.bouzidi@gmail.com>`__

     * Groupe C : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__ et `Jean Basset <jbasset001@ensc.fr>`__

     * Groupe D : `Ammar Ahmad <Ammar.Ahmad@u-bourgogne.fr>`__ et `Sameh Bouzidi <sameh.bouzidi@gmail.com>`__

Divers
-------

Le fichier `<cpp_s4.zip>`__ permet de télécharger tout le contenu du site en
une seule archive zip (utile pour conserver cette archive en fin de semestre).
